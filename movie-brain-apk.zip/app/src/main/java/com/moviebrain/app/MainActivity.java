package com.moviebrain.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    static final String UA = "Mozilla/5.0 (Linux; Android 13; SM-E315F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36";
    WebView brain, site;
    Button bBrain, bSite;
    SharedPreferences sp;
    boolean onSite = false;
    ValueCallback<Uri[]> fileCb;

    Button mk(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        return b;
    }

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        sp = getSharedPreferences("mb", MODE_PRIVATE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#10131a"));
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bBrain = mk("Movie Brain");
        bSite = mk("Site");
        bBrain.setOnClickListener(v -> showView(false));
        bSite.setOnClickListener(v -> showView(true));
        bar.addView(bBrain, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(bSite, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        FrameLayout fr = new FrameLayout(this);
        brain = new WebView(this);
        site = new WebView(this);
        fr.addView(brain, new FrameLayout.LayoutParams(-1, -1));
        fr.addView(site, new FrameLayout.LayoutParams(-1, -1));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        root.addView(fr, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        WebView.setWebContentsDebuggingEnabled(true);

        WebSettings w = brain.getSettings();
        w.setJavaScriptEnabled(true);
        w.setDomStorageEnabled(true);
        brain.addJavascriptInterface(new BrainBridge(), "Android");
        brain.setWebViewClient(new WebViewClient());
        brain.setWebChromeClient(new Chrome());
        brain.loadUrl("file:///android_asset/index.html");

        WebSettings ws = site.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setUserAgentString(UA);
        ws.setMediaPlaybackRequiresUserGesture(false);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(site, true);
        site.addJavascriptInterface(new SiteBridge(), "Bot");
        site.setWebChromeClient(new Chrome());
        site.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String u) {
                sp.edit().putString("url", u).apply();
            }
        });
        site.setDownloadListener((url, ua, cd, mime, len) -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setMimeType(mime);
                String ck = CookieManager.getInstance().getCookie(url);
                if (ck != null) r.addRequestHeader("Cookie", ck);
                r.addRequestHeader("User-Agent", ua);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime));
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "Download shuru ho gaya", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Is link se download nahi hua. Video par dabaye rakho ya site ka download button use karo.", Toast.LENGTH_LONG).show();
            }
        });
        site.loadUrl(sp.getString("url", "https://theresanaiforthat.com/"));
        showView(false);
    }

    void showView(boolean toSite) {
        onSite = toSite;
        brain.setVisibility(toSite ? View.INVISIBLE : View.VISIBLE);
        site.setVisibility(toSite ? View.VISIBLE : View.INVISIBLE);
        bBrain.setBackgroundColor(Color.parseColor(toSite ? "#202634" : "#2a8f82"));
        bSite.setBackgroundColor(Color.parseColor(toSite ? "#2a8f82" : "#202634"));
    }

    String readAsset(String n) throws Exception {
        InputStream in = getAssets().open(n);
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[4096];
        int k;
        while ((k = in.read(b)) > 0) o.write(b, 0, k);
        in.close();
        return o.toString("UTF-8");
    }

    @Override
    public void onBackPressed() {
        if (onSite && site.canGoBack()) site.goBack();
        else if (onSite) showView(false);
        else super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent i) {
        if (rq == 1 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, i));
            fileCb = null;
        }
    }

    class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(p.createIntent(), 1);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
            new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                .setPositiveButton("Haan", (d, x) -> r.confirm())
                .setNegativeButton("Nahi", (d, x) -> r.cancel())
                .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView v, String url, String msg, String def, JsPromptResult r) {
            EditText et = new EditText(MainActivity.this);
            et.setText(def);
            new AlertDialog.Builder(MainActivity.this).setMessage(msg).setView(et)
                .setPositiveButton("OK", (d, x) -> r.confirm(et.getText().toString()))
                .setNegativeButton("Cancel", (d, x) -> r.cancel())
                .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }
    }

    class BrainBridge {
        @JavascriptInterface
        public void generate(String prompt, String ori) {
            runOnUiThread(() -> {
                try {
                    String js = readAsset("site_inject.js")
                        .replace("__P__", JSONObject.quote(prompt))
                        .replace("__O__", JSONObject.quote(ori));
                    site.evaluateJavascript(js, null);
                } catch (Exception e) {
                    brain.evaluateJavascript("window.onBot&&window.onBot('error'," + JSONObject.quote("App error: " + e) + ")", null);
                }
            });
        }

        @JavascriptInterface
        public void show(String w) {
            runOnUiThread(() -> showView("site".equals(w)));
        }

        @JavascriptInterface
        public void keepAwake(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void vibrate() {
            try {
                ((Vibrator) getSystemService(Context.VIBRATOR_SERVICE)).vibrate(500);
            } catch (Exception e) { }
        }

        @JavascriptInterface
        public String saveFile(String name, String content) {
            try {
                byte[] data = content.getBytes(StandardCharsets.UTF_8);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    cv.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    OutputStream o = getContentResolver().openOutputStream(u);
                    o.write(data);
                    o.close();
                } else {
                    File f = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), name);
                    FileOutputStream o = new FileOutputStream(f);
                    o.write(data);
                    o.close();
                }
                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }
    }

    class SiteBridge {
        @JavascriptInterface
        public void report(String status, String detail) {
            runOnUiThread(() -> brain.evaluateJavascript(
                "window.onBot&&window.onBot(" + JSONObject.quote(status) + "," + JSONObject.quote(detail) + ")", null));
        }
    }
}
