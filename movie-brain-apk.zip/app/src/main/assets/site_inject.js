(async () => {
  const P = __P__;
  const ORI = __O__;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const rep = (s, d) => Bot.report(s, d || '');
  try {
    const lab = [...document.querySelectorAll('label,span,div,button')].filter(e =>
      e.children.length <= 2 && e.innerText && e.innerText.trim().toLowerCase() === ORI);
    if (lab[0]) lab[0].click();
    const ta = document.querySelector('textarea[placeholder*="prompt" i]') || document.querySelector('textarea');
    if (!ta) { rep('error', 'Prompt box nahi mila. Site tab me Video generator tool kholo aur login karo.'); return; }
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
    setter.call(ta, P);
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    ta.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(700);
    const gb = [...document.querySelectorAll('button')].find(b =>
      /^\s*generate\s*$/i.test(b.innerText || '') && !b.disabled && b.offsetParent);
    if (!gb) { rep('error', 'Generate button nahi mila ya band hai (login ya roz ki limit check karo).'); return; }
    const before = new Set([...document.querySelectorAll('video')].map(v => v.currentSrc || v.src));
    gb.click();
    rep('started');
    const t0 = Date.now();
    while (Date.now() - t0 < 6 * 60 * 1000) {
      await sleep(3000);
      const vs = [...document.querySelectorAll('video')].map(v => v.currentSrc || v.src).filter(s => s && !before.has(s));
      if (vs.length) { await sleep(1500); rep('done', vs[0]); return; }
    }
    rep('error', '6 minute me naya video nahi dikha. Site tab me check karo.');
  } catch (e) { rep('error', String(e)); }
})();
