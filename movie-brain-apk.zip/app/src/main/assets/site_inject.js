(async () => {
  const P = __P__;
  const ORI = __O__;
  const F = __F__;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const rep = (s, d) => Bot.report(s, d || '');
  try {
    const lab = [...document.querySelectorAll('label,span,div,button')].filter(e =>
      e.children.length <= 2 && e.innerText && e.innerText.trim().toLowerCase() === ORI);
    if (lab[0]) lab[0].click();
    const findTa = () => document.querySelector('textarea[placeholder*="prompt" i]') || document.querySelector('textarea');
    let ta = findTa();
    for (let k = 0; k < 20 && !ta; k++) { await sleep(1000); ta = findTa(); }
    if (!ta) { rep('error', 'Prompt box nahi mila. Site tab me Video generator tool kholo aur login karo.'); return; }
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
    ta.focus();
    setter.call(ta, P);
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    ta.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(800);
    let fnote = '';
    if (F) {
      const bin = atob(F), u8 = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      const file = new File([u8], 'last_frame.jpg', { type: 'image/jpeg' });
      const inputs = [...document.querySelectorAll('input[type=file]')];
      const inp = inputs.find(x => /image|png|jpe?g|webp/i.test(x.accept || '')) || inputs[0];
      if (!inp) { rep('error', 'Images upload box nahi mila.'); return; }
      const dt = new DataTransfer();
      dt.items.add(file);
      inp.files = dt.files;
      inp.dispatchEvent(new Event('input', { bubbles: true }));
      inp.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(3000);
      fnote = document.querySelectorAll('img[src^="blob:"],img[src^="data:"]').length ? ', last frame laga' : ', last frame lagne ki pushti nahi hui';
    }
    if ((ta.value || '').trim() !== P.trim()) {
      rep('error', 'Prompt box me text poora nahi gaya (' + (ta.value || '').length + ' / ' + P.length + ' akshar). Site tab me dekho.');
      return;
    }
    const gens = () => [...document.querySelectorAll('button')].filter(b => b.offsetParent && /generat/i.test(b.innerText || ''));
    const sig = () => gens().map(b => (b.innerText || '').trim() + (b.disabled ? '#d' : '')).join('|');
    const gb = gens().find(b => /^\s*generate\s*$/i.test(b.innerText || ''));
    if (!gb || gb.disabled) { rep('error', 'Generate button nahi mila ya band hai (login ya roz ki limit check karo).'); return; }
    const s0 = sig();
    gb.click();
    rep('started', 'prompt paste: ' + P.length + ' akshar' + fnote);
    let changed = false;
    const t1 = Date.now();
    while (Date.now() - t1 < 25000) { await sleep(1000); if (sig() !== s0) { changed = true; break; } }
    if (!changed) { rep('unsure', 'Site me koi badlav nahi dikha'); return; }
    const t0 = Date.now();
    while (Date.now() - t0 < 8 * 60 * 1000) {
      await sleep(3000);
      if (sig() === s0) { await sleep(2000); rep('done', ''); return; }
    }
    rep('error', '8 minute me clip khatam nahi hua. Site tab me dekho.');
  } catch (e) { rep('error', String(e)); }
})();
